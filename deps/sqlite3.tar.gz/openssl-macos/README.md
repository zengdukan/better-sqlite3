
OpenSSL 1.1.1l, built for arm64 and x86_64

Source: https://github.com/krzyzanowskim/OpenSSL/tree/23d8b94ae16d668b2916be1fdade7de375c6ccb0/macosx/lib
